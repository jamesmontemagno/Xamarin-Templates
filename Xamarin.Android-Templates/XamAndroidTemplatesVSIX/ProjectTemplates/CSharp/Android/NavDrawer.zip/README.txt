﻿Thank you for downloading the Xamarin.Android pack 

By default I added in the Mono.Android.Support.v4 for the
Navigation Drawer to work, however you should remove this reference and add 
the latest Support v4 Component. Simply right click on Components folder and 
search for Support v4. Or download from: https://components.xamarin.com/view/xamandroidsupportv4-18



Follow me on Twitter @JamesMontemagno and GitHub.com/JamesMontemagno